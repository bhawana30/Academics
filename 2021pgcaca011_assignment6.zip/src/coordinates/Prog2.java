package coordinates;

import coordinates.Cartesian;
import coordinates.Polar;
public class Prog2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cartesian c = new Cartesian();
		Polar p = new Polar();
		c.topolar(5, 6);
		p.tocartesian(5, 180);
	}

}
