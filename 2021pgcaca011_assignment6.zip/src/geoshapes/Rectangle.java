package geoshapes;

class Rectangle {

		void area(int l,int b) {
			int x = l*b;
			System.out.println("Area if Rectangle is : "+x);
		}
		void perimetre(int l,int b) {
			int x = 2*(l+b);
			System.out.println("Perimeter of rectangle is: "+x);
		}
	
}
