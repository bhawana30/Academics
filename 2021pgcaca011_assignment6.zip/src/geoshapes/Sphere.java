package geoshapes;

class Sphere {

	void Area(double r) {
		double x = 4*3.14*(r*r);
		System.out.println("Area of circle is: "+x);
	}
	

}
