package geoshapes;

class Circle {
	

	void Area(double r) {
		double x = 3.14*(r*r);
		System.out.println("Area of circle is: "+x);
	}
	void perimetre(double r) {
		double x = 2*3.14*r;
		System.out.println("perimeter of circle: "+x);
	}

}

