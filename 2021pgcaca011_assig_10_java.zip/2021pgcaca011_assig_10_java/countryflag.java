  // Write a java program using swing to create three buttons. On clicking the first
// button it displays “Good Morning”, clicking the second button displays “Hello” and
// clicking the third button displays “Welcome”.

// Java program to create a blank text 
// field of definite number of columns.
import java.awt.event.*;
import javax.swing.*;
class countryflag extends JFrame implements ActionListener {
	
	static JFrame f;
	static JButton b1;
	static JButton b2;
	static JButton b3;
	static JLabel l;

	
	public static void main(String[] args)
	{
		// create a new frame to store text field and button
		f = new JFrame("three button demo");

		// create a label to display text
		l = new JLabel("please press any button!");

		// create a new button
		b1 = new JButton("INDIA");
                  b2 = new JButton("USA");
                  b3 = new JButton("JAPAN");

		  countryflag te = new countryflag();
		b1.addActionListener(te);
		b2.addActionListener(te);
		b3.addActionListener(te);
        
		
		JPanel p = new JPanel();
		
		p.add(b1);
		p.add(b2);
		p.add(b3);
		p.add(l);

		f.add(p);

		// set the size of frame
		f.setSize(300, 300);

		f.show();
	}

	// if the button is pressed
	public void actionPerformed(ActionEvent e)
	{
		String s = e.getActionCommand();
		if (s.equals("INDIA")) {
		         ImageIcon i = new ImageIcon("india.jpeg");
			l.setIcon(i);
			l.setText("india");
			
		}
		if (s.equals("USA")) {
			ImageIcon it = new ImageIcon("usa.jpeg");
			l.setIcon(it);
			l.setText("usa");
			
		}
		if (s.equals("JAPAN")) {
			
			 ImageIcon itr = new ImageIcon("japan.jpeg");
			l.setIcon(itr);
			l.setText("japan");
			
		}
	}
}
