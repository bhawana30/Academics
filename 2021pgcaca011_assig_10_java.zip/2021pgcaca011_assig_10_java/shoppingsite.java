import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

public class shoppingsite extends JFrame {
    final private Font mainFont =new Font("Segoe print",Font.BOLD,18);
   JLabel lbWelcome;
   JCheckBox cd1,cd2,cd3,cd4,cd5,cd6;
   JLabel lbd1,lbd2,lbd3,lbd4,lbd5,lbd6;
  
    public void initialize(){ 
    /*****Form Panel***** */
    JLabel lbd1=new JLabel();
    ImageIcon i = new ImageIcon("dress1.jpeg");
	lbd1.setIcon(i);
    //***********************************
     JLabel lbd2=new JLabel();
    ImageIcon it = new ImageIcon("dress2.jpeg");
	lbd2.setIcon(it);
    //***********************************
     JLabel lbd3=new JLabel();
    ImageIcon itr= new ImageIcon("dress3.jpeg");
	lbd3.setIcon(itr);
    //***********************************
    JLabel lbd4=new JLabel();
    ImageIcon its = new ImageIcon("dress4.jpeg");
	lbd4.setIcon(its);
    //***********************************
    JLabel lbd5=new JLabel();
    ImageIcon ir = new ImageIcon("dress5.jpeg");
	lbd5.setIcon(ir);
    //***********************************
    JLabel lbd6=new JLabel();
    ImageIcon ig = new ImageIcon("dress6.jpeg");
	lbd6.setIcon(ig);
    //***********************************

    

    JPanel formPanel =new JPanel();
    formPanel.setLayout(new GridLayout(2,3,5,2));
    formPanel.add(lbd1);
     cd1 = new JCheckBox("black A-line Dress @500");
     cd1.setFont(mainFont);
    formPanel.add(cd1);
    //**********************************************************
    formPanel.add(lbd2);  
    cd2 = new JCheckBox("floral blue Dress @300");
    cd2.setFont(mainFont);
      formPanel.add(cd2);
      //**********************************************************
    formPanel.add(lbd3);  
     cd3 = new JCheckBox("Pleats Wrap Dress @480");
    cd3.setFont(mainFont);
      formPanel.add(cd3);
         //**********************************************************
    formPanel.add(lbd4);
    cd4 = new JCheckBox("Printed Wrap Dress @ 1356");
    cd4.setFont(mainFont);
      formPanel.add(cd4); 
        //**********************************************************
    formPanel.add(lbd5);
    cd5 = new JCheckBox("green silk Dress @1223");
    cd5.setFont(mainFont);
      formPanel.add(cd5);
   //**********************************************************
    formPanel.add(lbd6);
    cd6 = new JCheckBox(" white printed Dress @ 1245");
    cd6.setFont(mainFont);
      formPanel.add(cd6);
 
    /*****Welcome***** */
    lbWelcome=new JLabel();
    lbWelcome.setFont(mainFont);
    /*****Button Pannel****** */
    JButton btnOK=new JButton("OK");
    btnOK.setFont(mainFont);

    btnOK.addActionListener(new ActionListener(){

        @Override
        public void actionPerformed(ActionEvent e) {
            float amount=0;  
            String msg="";  
            if(cd1.isSelected()){  
                amount+=500; 
                msg+="black A-line Dress\n";
            }  
            if(cd2.isSelected()){  
                amount+=300;  
                msg+="floral blue Dress\n";  
            }  
            if(cd3.isSelected()){  
                amount+=480; 
                msg+="Pleats Wrap Dress\n";  
            } 
             if(cd4.isSelected()){  
                amount+=1356;  
                msg="Printed Wrap Dress\n";  
            }  
             if(cd5.isSelected()){  
                amount+=1223;  
                msg="green silk Dress @1223\n";  
            }  
             if(cd6.isSelected()){  
                amount+=1245;  
                msg=" white printed Dress @ 1245\n";  
            }   
            msg+="-----------------\n";  
            JOptionPane.showMessageDialog(null,msg+"Total: "+amount); 
        }

    });


    JButton btnClear=new JButton("Clear");
    btnClear.setFont(mainFont);
    btnClear.addActionListener(new ActionListener(){

        @Override
        public void actionPerformed(ActionEvent e) {
             
            lbWelcome.setText("");
        }});

        JPanel buttonsPanel=new JPanel();
        buttonsPanel.setLayout(new GridLayout(1,2,5,5));
        buttonsPanel.add(btnOK);
        buttonsPanel.add(btnClear);

JPanel mainPanel =new JPanel();
mainPanel.setLayout(new BorderLayout());
mainPanel.add(formPanel,BorderLayout.NORTH);
mainPanel.add(lbWelcome,BorderLayout.CENTER);
mainPanel.add(buttonsPanel,BorderLayout.SOUTH);

add(mainPanel);

    setTitle("Welcome");
    setSize(500,600);
    setMinimumSize(new Dimension(300,400));
    setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    setVisible(true);
   }

public static void main(String[] args) {
    shoppingsite myFrame=new shoppingsite();
    myFrame.initialize();
}


}
