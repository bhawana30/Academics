  // Write a java program using swing to create three buttons. On clicking the first
// button it displays “Good Morning”, clicking the second button displays “Hello” and
// clicking the third button displays “Welcome”.

// Java program to create a blank text 
// field of definite number of columns.
import java.awt.event.*;
import javax.swing.*;
class threebutton extends JFrame implements ActionListener {
	
	static JFrame f;
	static JButton b1;
	static JButton b2;
	static JButton b3;
	static JLabel l;

	
	public static void main(String[] args)
	{
		// create a new frame to store text field and button
		f = new JFrame("three button demo");

		// create a label to display text
		l = new JLabel("please press any button!");

		// create a new button
		b1 = new JButton("button 1");
                  b2 = new JButton("button 2");
                  b3 = new JButton("button 3");

		  threebutton te = new threebutton();
		b1.addActionListener(te);
		b2.addActionListener(te);
		b3.addActionListener(te);
        
		
		JPanel p = new JPanel();
		
		p.add(b1);
		p.add(b2);
		p.add(b3);
		p.add(l);

		f.add(p);

		// set the size of frame
		f.setSize(300, 300);

		f.show();
	}

	// if the button is pressed
	public void actionPerformed(ActionEvent e)
	{
		String s = e.getActionCommand();
		if (s.equals("button 1")) {
		        
			l.setText("Good Morning");
			
		}
		if (s.equals("button 2")) {
			
			l.setText("hello");
			
		}
		if (s.equals("button 3")) {
			
			l.setText("welcome");
			
		}
	}
}
